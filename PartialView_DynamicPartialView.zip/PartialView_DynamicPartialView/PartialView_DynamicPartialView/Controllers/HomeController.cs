﻿using Microsoft.AspNetCore.Mvc;
using PartialView_DynamicPartialView.Models;
using System.Diagnostics;
using static System.Net.Mime.MediaTypeNames;
using System.IO.Pipelines;
using System.Xml.Linq;

namespace PartialView_DynamicPartialView.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult About()
        {
            return View();
        }

        public IActionResult Product()
        {
            List<Product> products = new List<Product>()
            {
                new Product() { Id =101,Name="Rebock Shoes",Description="Desc 1",Price=100,Image="~/Images/shoes.jpeg"},
                new Product() { Id =102,Name="Wallet",Description="Desc 2",Price=500,Image="~/Images/wallet.jpeg"},
                new Product() {Id =103,Name="Goggles ",Description="Desc 3",Price=700,Image="~/Images/goggles.jpeg"}

            };
            return View(products);
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}